exec make hello.compile
